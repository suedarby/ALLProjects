    <!--page title--><?php include 'includes/header.php'; ?>
    <section class="container-fluid">
        <!--Top Nav-->
        <?php include 'includes/topnav.php';?>
        <div class="row">
            <!--Side Nav-->
            <?php include 'includes/sidenav.php';?>
            <!--BODY OF PAGE-->

            <div class="col">
                <h1>Contact</h1>
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <h3>Due to SPAMMERS all contact may be done via my <a
                                href="https://www.linkedin.com/in/suedarby/">LinkedIn
                                Profile</a></h3>
                    </div>
                </div>
            </div>
            <?php include 'includes/footer.php';?>

            </html>
            </body>