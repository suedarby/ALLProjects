 <!--FOOTER-->
 <footer class="container-fluid footer jumbotron">
     <div class=" text-center">
         <nav class="nav justify-content-center">
             <a class="nav-link active" href="index.php">Home</a>
             <a class="nav-link" href="about.php">About</a>
             <a class="nav-link" href="sitemap.php">Site Map</a>
         </nav>
         <p> &copy; 2020 Sue Darby</p>
         <p> Part of <a href="http://www.sue-a-darby.com/ladycodemonkey/index.php">Lady Code Monkey</a> &amp; <a
                 href="http://www.sue-a-darby.com/">Sue Darby's
                 Portfolio</a> </p>
     </div>
 </footer>