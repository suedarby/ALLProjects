 <!--LEFT SIDEBAR NAVIGATION-->
 <span class="sidebar">
     <nav class="nav">
         <div class="col-sm-3 sidebar">
             <h3 class="menu-side">Menu</h3>
             <ul class="nav nav-pills flex-column">
                 <li class="nav-item nav-list">
                     <ul>
                         <li class="nav nav-item nav-list"><a class="nav-link" href="index.php">Home</a>
                         </li>
                         <li class="nav nav-item nav-list"><a class="nav-link" href="about.php">About</a>
                         </li>
                         <li class="nav nav-item nav-list"><a class="nav-link" href="http://project-planning.sue-a-darby.com/">News *NEW</a>
                         </li>
                         <li class="nav nav-item nav-list"><a class="nav-link" href="skills.php">Skills</a>
                         </li>
                         <li class="nav nav-item nav-list"><a class="nav-link" href="experience.php">Experience</a>

                         <li class="nav nav-item nav-list"><a class="nav-link" href="projects.php">Projects</a>
                         </li>
                         <li class="nav nav-item nav-list"><a class="nav-link" href="achievements.php">Achievements</a>
                         </li>
                 </li>
                 <li class="nav nav-item nav-list"><a class="nav-link" href="education.php">Education</a>
                 </li>
                 <li class="nav nav-item nav-list"><a class="nav-link" href="contact.php">Contact</a></li>
                 <li class="nav nav-item nav-list"><a class="nav-link" href="privacy.php">Privacy</a></li>
                 <li class="nav nav-item nav-list"><a class="nav-link" href="site-map.php">Site
                         Map *NEW</a></li>
             </ul>

         </div>
     </nav>
 </span>
 <!--END LEFT SIDEBAR-->