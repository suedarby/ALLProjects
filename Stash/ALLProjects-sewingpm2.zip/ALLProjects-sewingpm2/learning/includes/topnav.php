<ul class="nav nav-tabs">
    <li class="nav-item">
        <a class="nav-link" href="index.php">Home</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="about.php">About</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="http://project-planning.sue-a-darby.com/">News</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="projects.php">Projects</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="site-map.php">Sitemap</a>
    </li>
</ul>
<!--END NAVIGATION-->