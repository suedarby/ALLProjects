<?php define("TITLE", "Nine Star Education &amp; Employment")?>
<?php include 'includes/header.php'; ?>

<section class="container"><!--page title-->
    <div class="row">
            <div class="col">
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <h2 class="card-title suedarbylg"><?php echo TITLE;?></h5>
    </div>
        </div>
            </div>
                </div>
</section>

<section class="container"><!--3 column-->
    <div class="row">
            <div class="col">
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title</p>
                        <a href="#" class="card-link">Another link</a>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title</p>
                        <a href="#" class="card-link">Another link</a>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text to build on the card title</p>
                        <a href="#" class="card-link">Another link</a>
                    </div>
            
                </div>
            </div>
        </div>
</section>


<?php include 'includes/footer.php';?>