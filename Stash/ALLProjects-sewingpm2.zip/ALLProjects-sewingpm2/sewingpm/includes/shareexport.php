<div class="btn-toolbar mb-2 mb-md-0">
    <!--Share, Export and Calendar-->
    <div class="btn-group mr-2">
        <button type="button" class="btn btn-sm btn-primary">Share</button>
        <button type="button" class="btn btn-sm btn-primary">Export</button>
    </div>
    <button type="button" class="btn btn-sm btn-primary dropdown-toggle">
        <span data-feather="calendar"></span>
        This week
    </button>
</div>