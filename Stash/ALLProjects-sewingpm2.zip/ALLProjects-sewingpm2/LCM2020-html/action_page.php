<!doctype html>
<!--NOTE TO SELF http://127.0.0.1:3000/-->
<html lang="en">
<!--INCLUDES ALL META TAGS AND OPENING HTML AND BODY TAGS-->
<?php include 'includes/header.php'; ?>
<?php include 'includes/nav2.php';?>

<!--MAIN PAGE CONTAINER-->
<div class="container-fluid" style="margin-top: 5px">
    <!--contaner-->
    <div class="row">
        <!--row-->
        <!--LEFT SIDEBAR NAVIGATION-->
        <?php include 'includes/left_side2.php';?>
        <!--MAIN PAGE CONTAINER-->
        <h1>Thank you for testing my script!</h1>
        </body>

</html>