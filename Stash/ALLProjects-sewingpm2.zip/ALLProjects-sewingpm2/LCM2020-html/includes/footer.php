 <!--FOOTER-->
 <footer class="footer jumbotron">
     <div class=" text-center">
         <nav class="nav justify-content-center">
             <a class="nav-link active" href="index.php">Home</a>
             <a class="nav-link" href="about.php">About</a>
             <a class="nav-link" href="sitemap.php">Site Map</a>
         </nav>
         <p> <a href="http://www.sue-a-darby.com/">&copy; 2020 Sue Darby</a></p>
         <p> <img src="images/Facebook.png" alt=""> </p>
     </div>
 </footer>