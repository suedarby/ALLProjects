<!--RIGHT SIDEBAR LINK TO ABOUT PAGE-->
    <div class="col-sm-3">
    <h2>About Me</h2>
      <p>Sue started coding before the internet was popular and didn't even realize it. She was 8 when her parents brought home a TI-994A console system...</p>
    </div>
<!--END RIGHT SIDEBAR-->
