<!-- Nav tabs -->
<ul class="nav nav-tabs" role="tablist">
    <li class="nav-item">
        <a class="nav-link active" data-toggle="tab" href="#home">Home</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#menu1">About</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#menu2">News</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#menu3">Portfolio</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#menu4">Sitemap</a>
    </li>
    </li>
</ul>


<!--END NAVIGATION-->