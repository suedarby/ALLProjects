<!--LEFT SIDEBAR START-->
<nav class="nav">
    <div class="col-sm-3">

        <ul class="nav flex-column">
            <li class="nav-item nav-list">
                <ul>
                    <li class="nav-item nav-list"><a class="nav-link active"
                            href="http://www.ladycodemonkey.sue-a-darby.com/index.php/">Home</a></li>
                    <li class="nav-item nav-list"><a class="nav-link"
                            href="http://www.ladycodemonkey.sue-a-darby.com/about.php">About</a></li>
                    <li class="nav-item nav-list"><a class="nav-link"
                            href="http://www.ladycodemonkey.sue-a-darby.com/news.php">News</a></li>
                    <li class="nav-item nav-list"><a class="nav-link"
                            href="http://www.ladycodemonkey.sue-a-darby.com/portfolio.php">Portfolio Page</a></li>
                    <ul>
                        <li class="nav-item nav-list"><a class="nav-link"
                                href="http://www.ladycodemonkey.sue-a-darby.com/form1.php">Form 1</a></li>
                        <li class="nav-item nav-list"><a class="nav-link"
                                href="http://www.ladycodemonkey.sue-a-darby.com/slider.php">Slider</a></li>
                        <li class="nav-item nav-list"><a class="nav-link"
                                href="http://www.ladycodemonkey.sue-a-darby.com/landing.php">Landing Page</a></li>
                        <li class="nav-item nav-list"><a class="nav-link"
                                href="http://www.ladycodemonkey.sue-a-darby.com/technicaldoc.php">Technical
                                Documentation</a></li>
                    </ul>
                    <li class="nav-item nav-list"><a class="nav-link"
                            href="http://www.ladycodemonkey.sue-a-darby.com/sitemap.php">Site Map</a></li>
                </ul>
    </div>
</nav>
<!--END LEFT SIDEBAR-->