 <!--LEFT SIDEBAR NAVIGATION-->
 <span class="sidebar">
     <nav class="nav">
         <div class="col-sm-3 sidebar">
             <h3 class="menu-side">Menu</h3>
             <ul class="nav nav-pills flex-column">
                 <li class="nav-item nav-list">
                     <ul>
                         <li class="nav nav-item nav-list"><a class="nav-link" href="index.php">Home</a>
                         </li>
                         <li class="nav nav-item nav-list"><a class="nav-link" href="about.php">About</a>
                         </li>
                         <li class="nav nav-item nav-list"><a class="nav-link" href="news.php">News</a>
                         </li>
                         <li class="nav nav-item nav-list"><a class="nav-link" href="portfolio.php">Portfolio
                                 Page</a>
                         </li>
                         <ul>
                             <li class="nav nav-item nav-list"><a class="nav-link"
                                     href="http://www.sue-a-darby.com/todoapp/index.php">To Do App</a></li>
                             <li class="nav nav-item nav-list"><a class="nav-link" href="slider.php">Slider</a>
                             </li>
                             <li class="nav nav-item nav-list"><a class="nav-link" href="landing.php">Landing
                                     Page</a>
                             </li>
                             <li class="nav nav-item nav-list"><a class="nav-link" href="technicaldoc.php">Technical
                                     Documentation</a></li>
                         </ul>
                         <li class="nav nav-item nav-list"><a class="nav-link" href="sitemap.php">Site
                                 Map</a></li>
                     </ul>
             </ul>
         </div>
     </nav>
 </span>
 <!--END LEFT SIDEBAR-->