<!--Top Nav-->
<ul class="nav nav-tabs">
    <li class="nav-item">
        <a class="nav-link" href="index.php">Home</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="about.php">About</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="news.php">News</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="portfolio.php">Portfolio</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="sitemap.php">Sitemap</a>
    </li>
</ul>
<!--END NAVIGATION-->