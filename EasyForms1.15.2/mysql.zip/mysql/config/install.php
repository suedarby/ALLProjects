<?php

$config = [
    'id' => 'mysql',
    'name'=> 'MySQL',
    'class' => 'app\modules\addons\modules\mysql\Module',
    'description'=> [
        'en-US' => 'Saving form data to a MySQL database.',
    ],
    'version' => '1.2.3',
];

return $config;
